function obj = minus( obj1, obj2 )
%  MINUS - Tensor subtraction.

obj = obj1 + ( - obj2 );
