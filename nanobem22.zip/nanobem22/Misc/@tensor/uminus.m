function obj = uminus( obj )
%  UMINUS - Unary minus.

obj.val = - obj.val;
