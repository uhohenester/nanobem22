function obj = dot( obj1, obj2, idx )
%  DOT - Dot product.

obj = sum( obj1 * obj2, idx );
