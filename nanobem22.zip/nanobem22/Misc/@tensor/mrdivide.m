function obj = mrdivide( obj, val )
%  MRDIVIDE - Division by scalar.

obj.val = obj.val / val;
